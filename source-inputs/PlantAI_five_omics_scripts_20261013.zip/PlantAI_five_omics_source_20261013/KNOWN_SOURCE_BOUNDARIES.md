# 原始源码边界与外部依赖

本包完整导出选定源码目录内所有现有脚本，逐文件保持字节一致；没有将原仓库不存在的文件描述为“已收齐”。

- `synteny_plot_revise` 在当前 stage_image_map.json 中 module=null，原仓库没有该独立入口。常规 `run_synteny.py` 已收录。
- `run_tree_plot.py` 的可选 `draw_msa_from_file.R` 未在当前及核对的原项目位置找到；原代码会检测存在性。独立 MSA 正式入口与 `msa_figure_from_aligned.R` 已收录。
- `run_phylogeny.py` 的候选 `msa_figure.mafft.R` 原仓库不存在；现有 `msa_figure_from_aligned.R`、`msa_figure.R`、实际名为 `msa_figure.mattf.R` 的历史脚本均原样收录，没有擅自改名。
- `plot_motif.R` 是候选名，原仓库无此文件；实际 `tree_motif.R` 已收录。
- Ka/Ks 可选 `plot_kaks.R` 从同用户原 PlantAI-dev 中找到，作为单独参考源码收录，见 FILE_ORIGINS.json；未修改当前仓库或运行链。
- 一些历史备用脚本仍导入 `apps.web`、旧 `agents/pipelines/workflows/utils`，当前拆分仓库不提供那些旧Web/Agent模块。本包保留这些原脚本以供审阅，不宣称它们可以独立运行。当前正式CLI与服务源码均收录；可按 ENTRYPOINTS.json 区分。
- `interproscan.sh`、`pal2nal.pl`、FastQC/fastp、HISAT2/STAR、Salmon、samtools、MEME、BLAST、MAFFT、IQ-TREE、MCScanX、Rscript、Nextflow、Java、Docker等属于外部安装工具。Python/R库、nf-core插件和数据库也不属于项目自有脚本，没有复制已安装环境。
- 四个 nf-core 固定版本包含完整脚本/模块/工作流源码；二进制说明图片、PDF和压缩测试数据不打包，逐项记录在 UPSTREAM_PROVENANCE.json。远程自定义配置、插件及镜像仍需另外准备。
- 原冻结启动器仍使用 `nextflow run nf-core/<name> -r <version>`；不擅自改写。可用包内 upstream_sources 对应目录直接运行 Nextflow，并另行提供 profile、参数、软件/容器与参考库。包含源码不等于离线免依赖运行。
- Dockerfile、requirements、环境版本文本只是构建/依赖说明；没有环境本体、容器层、可执行软件、私有.env或模型接口凭据。

本次只做来源完整性、哈希和压缩包校验，没有重新执行五类真实数据分析。既有验证范围以 analysis_skills/validation_scope.json 和原文档为准。
