# PlantAI 五类组学完整源码包

来源：隔离开发分支 `feature/sj-dev`，提交 `214e3b9079c4aa807beb5340642d18969a1e6530`。本次只归档源码，不修改服务器运行中的代码、服务、数据库或原流程包。

## 包含的五类流程

1. 基因家族：原始基因组准备、候选鉴定/精修、系统发育、亚家族、motif、domain、结构、启动子/TFBS、同线性、理化性质、直系同源、Ka/Ks、PPI、表达及报告。
2. 转录组 RNA-seq：QC、比对、定量、样本QC、DE、GO/KEGG/fgsea、WGCNA、候选家族关联和报告。
3. 单细胞/单核：FASTQ上游、矩阵QC/降维/聚类、审核注释、pseudobulk、DESeq2与富集。
4. 独立空间转录组：Sopa上游、SpatialData导出、切片QC/聚类/空间图/Moran与富集。
5. 宏基因组：taxprofiler、Bracken合并、群落/多样性、ANCOM-BC2、PERMANOVA与MAG。

## 主文件与辅助文件的位置

- `workflow_guides/`：五类流程各一份入口与函数位置索引。
- `ENTRYPOINTS.json`：逐阶段主入口、函数行号、导入依赖与引用脚本列表。
- `project_source/bioflow_kernel/cli/`：主要运行入口，保留原模块路径。
- `project_source/bioflow_kernel/gfa_core/`、`scripts/`：公共实现、绘图与辅助脚本。共享目录保持整体，避免拆分遗漏依赖；少量其它组学公共/历史代码也随目录原样保留。
- `project_source/bioflow_kernel/workflow_backends/`：三个新增组学完整冻结后端、原Skill与必要配置模板。保留原小型 backend.zip，因为 prepare_backend.py 直接使用它；不是环境包。
- `project_source/analysis_skills/`：当前五类组学Skill说明、绑定与验收范围。
- `upstream_sources/`：scrnaseq 4.2.0、sopa 1.0.1、taxprofiler 2.0.1、mag 5.5.0 的固定提交源码、模块、子工作流、配置、许可证；不只是启动器。
- `project_source/bioflow_service/`、`vstore/`：现有执行、审核、任务状态、产物登记/存储与公共代码。
- `project_source/sdk/`、`ui/`：对话接入与前端源码，作为项目集成附录；没有 node_modules 或构建环境。
- `project_source/docs/`：流程约定、参数示例与集成说明。
- `supplemental_reference/`：原项目找到的Ka/Ks可选绘图参考脚本，独立标注来源。

## 不包含的内容

不含 Conda/venv、site-packages、node_modules、容器镜像、系统软件、参考数据库、FASTQ/基因组示例大数据、分析结果、缓存、实际私有环境配置或账户凭据。轻量测试/构建脚本也原样保留，便于核对完整性；没有复制测试数据和运行环境。Dockerfile、requirements和版本文本只作为依赖说明保留。

## 完整性检查

当前项目源码文件 1015 个；导出范围内没有排除任何现有脚本。原冻结后端 47 个文件逐项通过既有哈希校验。五类正式阶段入口已核对。原仓库就缺失或仅作候选的文件见 `KNOWN_SOURCE_BOUNDARIES.md`，不会伪称打包后自动可运行。

`FILE_MANIFEST.tsv` 和 `SHA256SUMS.txt` 覆盖包内每个业务文件；`FILE_ORIGINS.json` 标出当前仓库、上游固定提交和补充参考的来源。`EXCLUDED_FILES.json` 逐项列出被排除的示例数据/历史结果等非源码内容。`EXPORT_ACCEPTANCE.json` 为导出验收记录。

解压后先读五份 workflow_guides，再使用真实输入和已准备的软件环境执行。部分R脚本由Python模板生成，生成器已收齐。完整导出代码不表示所有可选阶段已通过真实数据测试，原验证范围说明随包保留。

追加复核：四套上游流程的353处静态Nextflow模块引用全部找到；冻结原Skill内3个小型源码ZIP均CRC通过且无安装环境。独立检查见 `PACKAGING_VALIDATION.json`；打包与复核工具源码见 `packaging/`。
