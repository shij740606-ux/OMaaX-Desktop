#!/usr/bin/env python3
"""Export the five PlantAI workflows as source, without installed environments.

Run on the authorized server. Reads the checkout; writes only a new delivery folder.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import ast
import collections
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile

ROOT = Path('/home/xzq/5090/teamWorkspace/sj/sj_agent_dev_20261010')
REPO = ROOT / 'code'
OUT = ROOT / 'deliveries' / 'five_omics_source_20261013'
BUNDLE = OUT / 'PlantAI_five_omics_source_20261013'
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))
GROUPS = ('bioflow_kernel/', 'bioflow_service/', 'analysis_skills/', 'vstore/', 'sdk/', 'ui/')
SCRIPT_SUFFIXES = {'.py', '.R', '.r', '.sh', '.pl', '.pm', '.nf', '.js', '.ts', '.vue', '.groovy'}
UPSTREAM = [('scrnaseq', '4.2.0'), ('sopa', '1.0.1'), ('taxprofiler', '2.0.1'), ('mag', '5.5.0')]
MAX_DOWNLOAD = 100 * 1024 * 1024


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def emit(path, value):
    target = BUNDLE / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(value, encoding='utf-8')


def emit_json(path, value):
    emit(path, json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def reason_for_exclusion(rel):
    if rel.startswith('bioflow_kernel/assets/examples/'):
        return '示例测序/参考输入、BLAST索引或旧结果，不是脚本'
    if rel.startswith('bioflow_kernel/scripts/tree_motif_domain_structure.R/') and Path(rel).suffix != '.R':
        return '绘图示例输入或旧结果；同目录所有R源码保留'
    if Path(rel).suffix == '.swp':
        return '编辑器二进制交换文件'
    if rel.endswith('/learning_history.json'):
        return '历史运行学习记录，不是流程源码'
    if any(p in {'.git', '__pycache__', 'node_modules', '.venv', 'venv', 'site-packages'} for p in Path(rel).parts):
        return '安装环境、缓存或版本库元数据'
    if Path(rel).name == '.env' or Path(rel).name.startswith('.env.') and not rel.endswith('.example'):
        return '实际私有环境配置'
    return None


def fetch(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'PlantAI-source-export/1.0'})
    with OPENER.open(request, timeout=60) as response:
        data = response.read(MAX_DOWNLOAD + 1)
    if len(data) > MAX_DOWNLOAD:
        raise RuntimeError('Source archive exceeds 100 MiB limit')
    return data


def group(stage, spec):
    if stage.startswith('rnaseq') or stage in {'enrichment', 'expression'}:
        return 'rnaseq'
    if spec.get('workflow') in {'singlecell', 'spatial', 'metagenome'}:
        return spec['workflow']
    return 'gene_family'


def audit_entries(stage_map, included):
    entries = []
    for stage, spec in stage_map['stages'].items():
        if stage.startswith(('wgs', 'pop', 'gwas')):
            continue
        module = spec.get('module')
        rel = 'bioflow_kernel/' + module.replace('.', '/') + '.py' if module else None
        item = {'stage': stage, 'workflow': group(stage, spec), 'module': module,
                'main_file': 'project_source/' + rel if rel else None,
                'registered_executable': spec.get('executable', False),
                'present': rel in included if rel else False,
                'cli_contract': spec.get('cli_contract', []),
                'note': spec.get('note', '')}
        if rel and rel in included:
            text = (REPO / rel).read_text(encoding='utf-8')
            tree = ast.parse(text)
            imports = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                    imports.add(node.module)
                elif isinstance(node, ast.Import):
                    imports.update(n.name for n in node.names)
            item['imports'] = sorted(imports)
            item['script_references'] = sorted(set(re.findall(r'[A-Za-z0-9_./-]+\.(?:py|R|sh|pl|pm)\b', text)))
            item['local_import_sources'] = []
            for mod in sorted(imports):
                path = 'bioflow_kernel/' + mod.replace('.', '/')
                for candidate in (path + '.py', path + '/__init__.py'):
                    if candidate in included:
                        item['local_import_sources'].append('project_source/' + candidate)
            item['functions'] = [{'name': n.name, 'line': n.lineno} for n in tree.body
                                 if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        entries.append(item)
    return entries


def main():
    head = git('rev-parse', 'HEAD').decode().strip()
    branch = git('branch', '--show-current').decode().strip()
    status = git('status', '--porcelain', '--untracked-files=no')
    if status:
        raise RuntimeError('Tracked working tree is not clean; export would be ambiguous')
    BUNDLE.mkdir(parents=True, exist_ok=False)
    tracked = git('ls-files', '-z').decode().split('\0')[:-1]
    documentation = {'README.md', 'analysis_cli.py'}
    documentation.update(f for f in tracked if f.startswith('docs/omics'))
    documentation.update('docs/' + f for f in (
        'ANALYSIS_AGENT_ARCHITECTURE.md', 'API.md', 'EXTENSION_CONTRACT.md',
        'ISOLATED_DEVELOPMENT.md', 'MANUAL_TEST_BIOFLOW.md', 'DEPLOY_SKILL.md',
        'bioflow_image_build_playbook.md', 'bioflow_team_context.md'))
    documentation.update(f for f in tracked if f.startswith('docs/bioflow_corpus/'))
    scope = [f for f in tracked if f.startswith(GROUPS) or f in documentation]
    included, excluded, origins = [], [], {}
    for rel in scope:
        src = REPO / rel
        reason = reason_for_exclusion(rel)
        if reason:
            excluded.append({'path': rel, 'bytes': src.stat().st_size, 'reason': reason})
            continue
        if not src.is_file() or src.is_symlink() or not src.resolve().is_relative_to(REPO):
            raise RuntimeError('Non-regular or escaping tracked source: ' + rel)
        data = src.read_bytes()
        target = BUNDLE / 'project_source' / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(src.stat().st_mode & 0o777)
        included.append(rel)
        origins[target.relative_to(BUNDLE).as_posix()] = {'origin': 'current_checkout', 'source': str(src), 'sha256': sha(data)}
    # A genuinely referenced optional project-owned R plot is absent from this
    # clone, but exists in the original same-user development project. Include
    # it separately with provenance; do not patch the deployed checkout.
    optional = Path('/home/xzq/5090/teamWorkspace/sj/PlantAI-dev/skills/kaks/scripts/plot_kaks.R')
    if optional.is_file() and not optional.is_symlink():
        rel = 'supplemental_reference/skills/kaks/scripts/plot_kaks.R'
        data = optional.read_bytes()
        target = BUNDLE / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        origins[rel] = {'origin': 'optional_original_project_reference_not_integrated', 'source': str(optional), 'sha256': sha(data)}
    print('PROJECT copied', len(included), 'excluded', len(excluded), flush=True)
    downloads, upstream_sources = [], {}
    total_download = 0
    for name, tag in UPSTREAM:
        tag_url = f'https://api.github.com/repos/nf-core/{name}/git/ref/tags/{tag}'
        ref = json.loads(fetch(tag_url))
        obj = ref['object']
        while obj['type'] == 'tag':
            obj = json.loads(fetch(obj['url']))['object']
        if obj['type'] != 'commit':
            raise RuntimeError('Expected a commit for pinned upstream tag')
        commit = obj['sha']
        url = f'https://codeload.github.com/nf-core/{name}/tar.gz/{commit}'
        archive = fetch(url)
        total_download += len(archive)
        if total_download > MAX_DOWNLOAD:
            raise RuntimeError('Combined source downloads exceed 100 MiB')
        # Keep downloaded archives outside the final bundle; export source only.
        archive_path = OUT / f'{name}-{tag}-source.tar.gz'
        archive_path.write_bytes(archive)
        dest = BUNDLE / 'upstream_sources' / f'nf-core_{name}_{tag}'
        count = 0
        omitted = []
        with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
            for member in tar.getmembers():
                parts = PurePosixPath(member.name).parts
                if not parts or len(parts) == 1 or member.isdir():
                    continue
                relative = PurePosixPath(*parts[1:])
                if relative.is_absolute() or '..' in relative.parts or not member.isfile():
                    raise RuntimeError('Unsafe/nonregular archive member: ' + member.name)
                target = dest / relative.as_posix()
                if not target.resolve().is_relative_to(dest.resolve()):
                    raise RuntimeError('Archive traversal')
                # nf-core source contains no installed environment. Exclude
                # binary docs images and data fixtures while keeping all code,
                # configs, lock files, licences, test scripts and text schemas.
                if target.suffix.lower() in {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.pdf',
                                            '.fastq', '.fq', '.bam', '.cram', '.h5', '.h5ad',
                                            '.gz', '.zip', '.tif', '.tiff'}:
                    omitted.append(relative.as_posix())
                    continue
                handle = tar.extractfile(member)
                if handle is None:
                    raise RuntimeError('Unreadable source archive member')
                data = handle.read()
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                target.chmod(member.mode & 0o777)
                rel = target.relative_to(BUNDLE).as_posix()
                origins[rel] = {'origin': f'nf-core/{name}', 'revision': tag, 'commit': commit,
                                'archive_member': member.name, 'sha256': sha(data)}
                count += 1
        if not (dest / 'main.nf').is_file() or not (dest / 'nextflow.config').is_file():
            raise RuntimeError('Incomplete upstream checkout')
        licences = [p.name for p in dest.iterdir() if p.name.upper().startswith(('LICENSE', 'LICENCE', 'COPYING'))]
        if not licences:
            raise RuntimeError('Missing upstream license: ' + name)
        metadata = {'repository': f'nf-core/{name}', 'tag': tag, 'commit': commit,
                    'archive_url': url, 'archive_sha256': sha(archive), 'download_bytes': len(archive),
                    'included_source_files': count, 'excluded_binary_docs_or_data': omitted,
                    'licenses': licences, 'package_path': dest.relative_to(BUNDLE).as_posix()}
        downloads.append(metadata)
        upstream_sources[name] = metadata
        print('UPSTREAM', name, tag, count, len(archive), flush=True)
    stage_map = json.loads((REPO / 'bioflow_kernel/stage_image_map.json').read_text())
    entries = audit_entries(stage_map, set(included))
    missing_entries = [e['stage'] for e in entries if not e['present']]
    if missing_entries != ['synteny_plot_revise']:
        raise RuntimeError('Unexpected main entry gaps: ' + repr(missing_entries))
    freeze = json.loads((REPO / 'bioflow_kernel/workflow_backends/provenance.json').read_text())
    frozen_verified = 0
    for name, spec in freeze.items():
        for rel, expected in spec['files'].items():
            data = (BUNDLE / 'project_source/bioflow_kernel/workflow_backends' / name / rel).read_bytes()
            if sha(data) != expected:
                raise RuntimeError('Frozen backend differs: ' + name + '/' + rel)
            frozen_verified += 1
    required = {f'bioflow_kernel/workflow_backends/{g}/run.py' for g in ['singlecell', 'spatial', 'metagenome']}
    required |= {f'bioflow_kernel/{stage_map["stages"][s]["module"].replace(".", "/")}.py'
                 for s in stage_map['family_chain']}
    if not required <= set(included):
        raise RuntimeError('Required scientific script missing')
    excluded_scripts = [e for e in excluded if Path(e['path']).suffix in SCRIPT_SUFFIXES]
    if excluded_scripts:
        raise RuntimeError('Source scripts excluded by packaging filter: ' + repr(excluded_scripts))
    emit_json('FILE_ORIGINS.json', origins)
    emit_json('EXCLUDED_FILES.json', excluded)
    emit_json('UPSTREAM_PROVENANCE.json', downloads)
    emit_json('ENTRYPOINTS.json', entries)
    for name, label in [('gene_family', '基因家族'), ('rnaseq', '转录组RNA-seq'),
                        ('singlecell', '单细胞与单核转录组'), ('spatial', '独立空间转录组'), ('metagenome', '宏基因组')]:
        subset = [e for e in entries if e['workflow'] == name]
        lines = [f'# {label}：入口与辅助代码\n',
                 '下面保留当前阶段映射中的正式入口、别名及旧入口。注册或文件存在不等于已通过真实数据验收。\n',
                 '| 阶段 | 主运行文件 | 当前注册状态 |\n|---|---|---|']
        for e in subset:
            path = e['main_file'] or '原仓库未提供模块'
            state = '有源码' if e['present'] else '原仓库缺失'
            state += '；启用' if e['registered_executable'] else '；未启用'
            lines.append(f'| {e["stage"]} | `{path}` | {state} |')
        lines += ['\n## 调用说明\n',
                  '主运行文件位于 `project_source/bioflow_kernel/cli/`；同级 `__init__.py`、公共工具以及 `gfa_core/` 不能省略。',
                  '外置R/Python/Perl/Shell辅助脚本位于 `project_source/bioflow_kernel/scripts/`。',
                  '逐入口的函数起始行、导入模块、本地导入对应文件及脚本字符串引用均见根目录 `ENTRYPOINTS.json`。字符串引用可能是运行时生成文件或可选候选名，不能直接视为缺文件。\n']
        if name in {'singlecell', 'spatial', 'metagenome'}:
            lines += [f'项目适配器：`project_source/bioflow_kernel/cli/run_omics.py`，调用 `workflow_backends/{name}/run.py`、`src/` 或 `scripts/`。',
                      f'原后端详细步骤：`project_source/bioflow_kernel/workflow_backends/{name}/docs/WORKFLOW.md`。',
                      f'当前项目Skill：`project_source/analysis_skills/{name}/`；冻结原Skill在 `workflow_backends/skills/`。',
                      '正式参数模板见 `project_source/docs/omics_examples/`；输入和产物约定见 `workflow_backends/stages.json`。']
        if name == 'gene_family':
            lines += ['默认家族阶段顺序：`' + ' → '.join(stage_map['family_chain']) + '`。',
                      'Ka/Ks可选原项目绘图脚本另存 `supplemental_reference/skills/kaks/scripts/plot_kaks.R`，没有自动接入或替换现有代码。']
        if name == 'rnaseq':
            lines += ['主链：QC → 比对 → 定量 → 样本QC → 差异表达 → 富集/fgsea/可选WGCNA → 报告；允许从合法中间输入开始。',
                      '`run_deseq2.R`、`run_sample_qc.R`、`run_enrichment_orgdb.R`、`run_fgsea_kegg.R`、`run_wgcna.R` 由对应 Python CLI 的模板/构建函数生成；生成代码完整保留在Python源文件中。']
        for e in subset:
            if e.get('functions'):
                lines += [f'\n### {e["stage"]}\n', '`' + str(e['main_file']) + '`',
                          '\n函数位置：' + '；'.join(f'{n["name"]}:{n["line"]}' for n in e['functions'])]
        emit(f'workflow_guides/{name}.md', '\n'.join(lines) + '\n')
    emit('KNOWN_SOURCE_BOUNDARIES.md', '''# 原始源码边界与外部依赖

本包完整导出选定源码目录内所有现有脚本，逐文件保持字节一致；没有将原仓库不存在的文件描述为“已收齐”。

- `synteny_plot_revise` 在当前 stage_image_map.json 中 module=null，原仓库没有该独立入口。常规 `run_synteny.py` 已收录。
- `run_tree_plot.py` 的可选 `draw_msa_from_file.R` 未在当前及核对的原项目位置找到；原代码会检测存在性。独立 MSA 正式入口与 `msa_figure_from_aligned.R` 已收录。
- `run_phylogeny.py` 的候选 `msa_figure.mafft.R` 原仓库不存在；现有 `msa_figure_from_aligned.R`、`msa_figure.R`、实际名为 `msa_figure.mattf.R` 的历史脚本均原样收录，没有擅自改名。
- `plot_motif.R` 是候选名，原仓库无此文件；实际 `tree_motif.R` 已收录。
- Ka/Ks 可选 `plot_kaks.R` 从同用户原 PlantAI-dev 中找到，作为单独参考源码收录，见 FILE_ORIGINS.json；未修改当前仓库或运行链。
- 一些历史备用脚本仍导入 `apps.web`、旧 `agents/pipelines/workflows/utils`，当前拆分仓库不提供那些旧Web/Agent模块。本包保留这些原脚本以供审阅，不宣称它们可以独立运行。当前正式CLI与服务源码均收录；可按 ENTRYPOINTS.json 区分。
- `interproscan.sh`、`pal2nal.pl`、FastQC/fastp、HISAT2/STAR、Salmon、samtools、MEME、BLAST、MAFFT、IQ-TREE、MCScanX、Rscript、Nextflow、Java、Docker等属于外部安装工具。Python/R库、nf-core插件和数据库也不属于项目自有脚本，没有复制已安装环境。
- 四个 nf-core 固定版本包含完整脚本/模块/工作流源码；二进制说明图片、PDF和压缩测试数据不打包，逐项记录在 UPSTREAM_PROVENANCE.json。远程自定义配置、插件及镜像仍需另外准备。
- 原冻结启动器仍使用 `nextflow run nf-core/<name> -r <version>`；不擅自改写。可用包内 upstream_sources 对应目录直接运行 Nextflow，并另行提供 profile、参数、软件/容器与参考库。包含源码不等于离线免依赖运行。
- Dockerfile、requirements、环境版本文本只是构建/依赖说明；没有环境本体、容器层、可执行软件、私有.env或模型接口凭据。

本次只做来源完整性、哈希和压缩包校验，没有重新执行五类真实数据分析。既有验证范围以 analysis_skills/validation_scope.json 和原文档为准。
''')
    script_counts = collections.Counter(p.suffix for p in BUNDLE.rglob('*') if p.is_file() and p.suffix in SCRIPT_SUFFIXES)
    acceptance = {'created_utc': datetime.now(timezone.utc).isoformat(), 'source_root': str(REPO),
                  'branch': branch, 'commit': head, 'project_source_files': len(included),
                  'all_existing_scripts_in_selected_directories_included': not excluded_scripts,
                  'excluded_non_source_files': len(excluded), 'scripts_by_suffix': dict(script_counts),
                  'five_workflow_groups': sorted(set(e['workflow'] for e in entries)),
                  'mapped_stage_records': len(entries), 'mapped_entries_present': sum(e['present'] for e in entries),
                  'original_missing_entry_records': missing_entries, 'frozen_backend_files_hash_verified': frozen_verified,
                  'upstream_download_bytes': total_download, 'upstream_pipelines': downloads,
                  'environment_payload_included': False, 'fresh_biological_execution_performed': False}
    emit_json('EXPORT_ACCEPTANCE.json', acceptance)
    emit('README_先看这里.md', f'''# PlantAI 五类组学完整源码包

来源：隔离开发分支 `{branch}`，提交 `{head}`。本次只归档源码，不修改服务器运行中的代码、服务、数据库或原流程包。

## 包含的五类流程

1. 基因家族：原始基因组准备、候选鉴定/精修、系统发育、亚家族、motif、domain、结构、启动子/TFBS、同线性、理化性质、直系同源、Ka/Ks、PPI、表达及报告。
2. 转录组 RNA-seq：QC、比对、定量、样本QC、DE、GO/KEGG/fgsea、WGCNA、候选家族关联和报告。
3. 单细胞/单核：FASTQ上游、矩阵QC/降维/聚类、审核注释、pseudobulk、DESeq2与富集。
4. 独立空间转录组：Sopa上游、SpatialData导出、切片QC/聚类/空间图/Moran与富集。
5. 宏基因组：taxprofiler、Bracken合并、群落/多样性、ANCOM-BC2、PERMANOVA与MAG。

## 主文件与辅助文件的位置

- `workflow_guides/`：五类流程各一份入口与函数位置索引。
- `ENTRYPOINTS.json`：逐阶段主入口、函数行号、导入依赖与引用脚本列表。
- `project_source/bioflow_kernel/cli/`：主要运行入口，保留原模块路径。
- `project_source/bioflow_kernel/gfa_core/`、`scripts/`：公共实现、绘图与辅助脚本。共享目录保持整体，避免拆分遗漏依赖；少量其它组学公共/历史代码也随目录原样保留。
- `project_source/bioflow_kernel/workflow_backends/`：三个新增组学完整冻结后端、原Skill与必要配置模板。保留原小型 backend.zip，因为 prepare_backend.py 直接使用它；不是环境包。
- `project_source/analysis_skills/`：当前五类组学Skill说明、绑定与验收范围。
- `upstream_sources/`：scrnaseq 4.2.0、sopa 1.0.1、taxprofiler 2.0.1、mag 5.5.0 的固定提交源码、模块、子工作流、配置、许可证；不只是启动器。
- `project_source/bioflow_service/`、`vstore/`：现有执行、审核、任务状态、产物登记/存储与公共代码。
- `project_source/sdk/`、`ui/`：对话接入与前端源码，作为项目集成附录；没有 node_modules 或构建环境。
- `project_source/docs/`：流程约定、参数示例与集成说明。
- `supplemental_reference/`：原项目找到的Ka/Ks可选绘图参考脚本，独立标注来源。

## 不包含的内容

不含 Conda/venv、site-packages、node_modules、容器镜像、系统软件、参考数据库、FASTQ/基因组示例大数据、分析结果、缓存、实际私有环境配置或账户凭据。轻量测试/构建脚本也原样保留，便于核对完整性；没有复制测试数据和运行环境。Dockerfile、requirements和版本文本只作为依赖说明保留。

## 完整性检查

当前项目源码文件 {len(included)} 个；导出范围内没有排除任何现有脚本。原冻结后端 {frozen_verified} 个文件逐项通过既有哈希校验。五类正式阶段入口已核对。原仓库就缺失或仅作候选的文件见 `KNOWN_SOURCE_BOUNDARIES.md`，不会伪称打包后自动可运行。

`FILE_MANIFEST.tsv` 和 `SHA256SUMS.txt` 覆盖包内每个业务文件；`FILE_ORIGINS.json` 标出当前仓库、上游固定提交和补充参考的来源。`EXCLUDED_FILES.json` 逐项列出被排除的示例数据/历史结果等非源码内容。`EXPORT_ACCEPTANCE.json` 为导出验收记录。

解压后先读五份 workflow_guides，再使用真实输入和已准备的软件环境执行。部分R脚本由Python模板生成，生成器已收齐。完整导出代码不表示所有可选阶段已通过真实数据测试，原验证范围说明随包保留。
''')
    # All generated provenance and guides are integrity protected as well.
    records = []
    for file in sorted(BUNDLE.rglob('*')):
        if file.is_file():
            rel = file.relative_to(BUNDLE).as_posix()
            data = file.read_bytes()
            records.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
    emit('FILE_MANIFEST.tsv', 'path\tbytes\tsha256\n' + ''.join(f'{v["path"]}\t{v["bytes"]}\t{v["sha256"]}\n' for v in records))
    emit('SHA256SUMS.txt', ''.join(f'{v["sha256"]}  {v["path"]}\n' for v in records))
    archive = OUT / (BUNDLE.name + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for file in sorted(BUNDLE.rglob('*')):
            if file.is_file():
                z.write(file, BUNDLE.name + '/' + file.relative_to(BUNDLE).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('ZIP CRC verification failed')
        for record in records:
            if sha(z.read(BUNDLE.name + '/' + record['path'])) != record['sha256']:
                raise RuntimeError('ZIP content differs from manifest')
        for rel, origin in origins.items():
            if sha(z.read(BUNDLE.name + '/' + rel)) != origin['sha256']:
                raise RuntimeError('Source copy differs from origin')
        zip_count = len(z.namelist())
    if git('rev-parse', 'HEAD').decode().strip() != head or git('status', '--porcelain', '--untracked-files=no') != status:
        raise RuntimeError('Source checkout changed during export')
    archive_sha = sha(archive.read_bytes())
    (OUT / (archive.name + '.sha256')).write_text(archive_sha + '  ' + archive.name + '\n')
    for name in ['README_先看这里.md', 'EXPORT_ACCEPTANCE.json', 'KNOWN_SOURCE_BOUNDARIES.md']:
        shutil.copy2(BUNDLE / name, OUT / name)
    summary = {'zip': str(archive), 'sha256': archive_sha, 'zip_bytes': archive.stat().st_size,
               'archive_files': zip_count, 'project_source_files': len(included),
               'scripts_total': sum(script_counts.values()), 'scripts_by_suffix': dict(script_counts),
               'upstream_source_files': sum(d['included_source_files'] for d in downloads),
               'crc_and_every_file_hash_verified': True, 'source_checkout_unchanged': True}
    (OUT / 'DELIVERY_VERIFIED.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
