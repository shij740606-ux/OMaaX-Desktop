"""Independent checks of the exported source closure and final ZIP integrity."""
from pathlib import Path
import collections
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path('/home/xzq/5090/teamWorkspace/sj/sj_agent_dev_20261010')
OUT = ROOT / 'deliveries/five_omics_source_20261013'
BUNDLE = OUT / 'PlantAI_five_omics_source_20261013'
suffixes = {'.py', '.R', '.r', '.sh', '.pl', '.pm', '.nf', '.js', '.ts', '.vue', '.groovy'}
sha = lambda data: hashlib.sha256(data).hexdigest()
checks = []
for source in (BUNDLE / 'upstream_sources').rglob('*.nf'):
    text = source.read_text()
    for match in re.finditer(r'include\s*\{[^}]+\}\s*from\s*[\'"]([^\'"]+)[\'"]', text, re.S):
        value = match.group(1)
        if not value.startswith('.'):
            continue
        target = source.parent / value
        found = next((p for p in [target, Path(str(target) + '.nf'), target / 'main.nf'] if p.is_file()), None)
        if found is None or not found.resolve().is_relative_to(BUNDLE.resolve()):
            raise RuntimeError('Missing or escaping Nextflow source import: ' + str(source) + ': ' + value)
        checks.append({'source': source.relative_to(BUNDLE).as_posix(), 'reference': value,
                       'target': found.relative_to(BUNDLE).as_posix()})
assert len(checks) == 353
origins = json.loads((BUNDLE / 'FILE_ORIGINS.json').read_text())
for relative, origin in origins.items():
    assert sha((BUNDLE / relative).read_bytes()) == origin['sha256'], relative
    if origin['origin'] == 'current_checkout':
        assert sha(Path(origin['source']).read_bytes()) == origin['sha256'], relative
backend_archives = []
for archive in (BUNDLE / 'project_source/bioflow_kernel/workflow_backends/skills').rglob('backend.zip'):
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert not any('site-packages' in name or 'node_modules' in name or '..' in Path(name).parts for name in z.namelist())
        backend_archives.append({'path': archive.relative_to(BUNDLE).as_posix(), 'files': len(z.namelist()), 'crc_ok': True})
(BUNDLE / 'packaging').mkdir(exist_ok=True)
shutil.copy2(ROOT / 'export_five_omics_20261013.py', BUNDLE / 'packaging/export_bundle.py')
shutil.copy2(Path(__file__), BUNDLE / 'packaging/finalize_bundle.py')
validation = {'upstream_static_includes_checked': len(checks), 'missing_static_imports': 0,
              'static_imports': checks, 'frozen_nested_archives': backend_archives,
              'all_source_origins_reverified_against_export': True,
              'project_source_reverified_against_live_checkout': True,
              'scope': 'source packaging and integrity; not new scientific execution'}
(BUNDLE / 'PACKAGING_VALIDATION.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
counts = collections.Counter(p.suffix for p in BUNDLE.rglob('*') if p.is_file() and p.suffix in suffixes)
acceptance = json.loads((BUNDLE / 'EXPORT_ACCEPTANCE.json').read_text())
acceptance.update(scripts_by_suffix=dict(counts), upstream_static_includes_checked=len(checks),
                  missing_static_imports=0, reproducible_packaging_scripts_included=True)
(BUNDLE / 'EXPORT_ACCEPTANCE.json').write_text(json.dumps(acceptance, ensure_ascii=False, indent=2) + '\n')
addition = '\n追加复核：四套上游流程的353处静态Nextflow模块引用全部找到；冻结原Skill内3个小型源码ZIP均CRC通过且无安装环境。独立检查见 `PACKAGING_VALIDATION.json`；打包与复核工具源码见 `packaging/`。\n'
if addition not in (BUNDLE / 'README_先看这里.md').read_text(encoding='utf-8'):
    with (BUNDLE / 'README_先看这里.md').open('a', encoding='utf-8') as h:
        h.write(addition)
records = []
for file in sorted(BUNDLE.rglob('*')):
    if file.is_file() and file.relative_to(BUNDLE).as_posix() not in {'FILE_MANIFEST.tsv', 'SHA256SUMS.txt'}:
        data = file.read_bytes()
        records.append({'path': file.relative_to(BUNDLE).as_posix(), 'bytes': len(data), 'sha256': sha(data)})
(BUNDLE / 'FILE_MANIFEST.tsv').write_text('path\tbytes\tsha256\n' + ''.join(f'{v["path"]}\t{v["bytes"]}\t{v["sha256"]}\n' for v in records))
(BUNDLE / 'SHA256SUMS.txt').write_text(''.join(f'{v["sha256"]}  {v["path"]}\n' for v in records))
archive = OUT / 'PlantAI_five_omics_scripts_20261013.zip'
if archive.exists():
    backup = OUT / 'PlantAI_five_omics_scripts_20261013_firstattempt.zip'
    if backup.exists():
        raise RuntimeError('A previous recovery backup already exists')
    archive.rename(backup)
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for file in sorted(BUNDLE.rglob('*')):
        if file.is_file():
            z.write(file, BUNDLE.name + '/' + file.relative_to(BUNDLE).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(records) + 2
    for record in records:
        assert sha(z.read(BUNDLE.name + '/' + record['path'])) == record['sha256'], record['path']
    file_count = len(z.namelist())
checksum = sha(archive.read_bytes())
(OUT / (archive.name + '.sha256')).write_text(checksum + '  ' + archive.name + '\n')
for name in ['README_先看这里.md', 'EXPORT_ACCEPTANCE.json', 'PACKAGING_VALIDATION.json', 'FILE_MANIFEST.tsv', 'KNOWN_SOURCE_BOUNDARIES.md']:
    shutil.copy2(BUNDLE / name, OUT / name)
summary = {'zip': str(archive), 'sha256': checksum, 'zip_bytes': archive.stat().st_size,
           'archive_files': file_count, 'scripts_total': sum(counts.values()),
           'scripts_by_suffix': dict(counts), 'upstream_static_imports_checked': len(checks),
           'zip_crc_and_all_file_hashes_passed': True, 'source_checkout_unchanged': True}
(OUT / 'FINAL_DELIVERY_VERIFIED.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False), flush=True)
