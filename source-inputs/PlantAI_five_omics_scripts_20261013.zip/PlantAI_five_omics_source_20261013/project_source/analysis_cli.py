"""Typed client for PlantAI analysis APIs; never accepts shell commands."""
from __future__ import annotations
import argparse,json,sys,urllib.request,urllib.error
from pathlib import Path
def outcome_code(command,payload):
 if payload.get("ok") is False:return 1
 data=payload.get("data") or {}
 if command=="validate" and data.get("valid") is False:return 2
 if command=="preflight" and (data.get("validation",{}).get("valid") is False or data.get("readiness",{}).get("ready") is False):return 2
 return 0
def main(argv=None):
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("--base-url",default="http://127.0.0.1:8198")
 sub=p.add_subparsers(dest="command",required=True)
 sub.add_parser("capabilities");sub.add_parser("plans");sub.add_parser("assets")
 for cmd in ("inspect","validate","plan","chat"):
  s=sub.add_parser(cmd);s.add_argument("--json",required=True,help="JSON request file; use - for stdin")
 for cmd in ("status","preflight","artifacts","deliver","execute","pause","cancel","resume","retry","revise"):
  s=sub.add_parser(cmd);s.add_argument("plan_id")
  if cmd in ("deliver","execute","pause","cancel","resume","retry","revise"):
   s.add_argument("--revision",type=int,required=True);s.add_argument("--key",required=True)
  if cmd=="retry":s.add_argument("--stage",required=True)
  if cmd=="revise":s.add_argument("--json",required=True)
 a=p.parse_args(argv);cmd=a.command;body=None;method="GET"
 root="/api/bioflow/analysis"
 if cmd in ("capabilities","plans","assets"):path=root+"/"+cmd
 elif cmd in ("inspect","validate","plan","chat"):
  value=sys.stdin.read() if a.json=="-" else Path(a.json).read_text()
  body=json.loads(value);method="POST";path=root+"/"+{"inspect":"assets","plan":"plans"}.get(cmd,cmd)
 else:
  path=root+"/plans/"+a.plan_id
  if cmd=="status":pass
  elif cmd=="preflight":path+="/preflight";method="POST";body={}
  elif cmd=="artifacts":path+="/artifacts"
  else:
   method="POST";body={"expected_revision":a.revision,"idempotency_key":a.key}
   if cmd=="deliver":path+="/deliver"
   else:
    path+="/actions/"+{"execute":"start"}.get(cmd,cmd)
    if cmd in ("execute","retry","resume"):body["authorization"]="execute_registered_plan"
    if cmd=="retry":body["stage"]=a.stage
    if cmd=="revise":
     body.update(json.loads(Path(a.json).read_text()))
 request=urllib.request.Request(a.base_url.rstrip("/")+path,data=json.dumps(body).encode() if body is not None else None,headers={"Content-Type":"application/json"},method=method)
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 try:
  with opener.open(request,timeout=120) as response:
   payload=json.loads(response.read());print(json.dumps(payload,ensure_ascii=False));return outcome_code(cmd,payload)
 except urllib.error.HTTPError as e:print(e.read().decode());return 1
if __name__=="__main__":raise SystemExit(main())
