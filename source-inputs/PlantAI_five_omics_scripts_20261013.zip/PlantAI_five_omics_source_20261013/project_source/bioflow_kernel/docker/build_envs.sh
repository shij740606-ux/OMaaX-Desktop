#!/usr/bin/env bash
# build_envs.sh —— 非内核环境镜像构建(plantai-env-* 系列, playbook §8 台账 9-24 号)
# 方法: docs/bioflow_image_build_playbook.md; 与 build_all.sh 同级的第二个构建入口。
# 用法: build_envs.sh <comma-list|all> [pack-dir]
#   pack-dir: 存放 conda-pack 产物 <env>.tar.gz 的目录; 默认 bioflow-image-build。
set -euo pipefail

TARGET="${1:-all}"
PACK_DIR="${2:-/home/xzq/5090/teamWorkspace/zh/bioflow-image-build}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DF_DIR="$SCRIPT_DIR/extra-envs"
TAG="${PLANTAI_ENV_TAG:-20260906}"

# 镜像名 -> 源 tar(构建顺序: 大 tar 先行, I/O 平摊)
declare -A TARS=(
  [minerupy312]=minerupy312.tar.gz
  [at-sc]=at_sc.tar.gz
  [snpeff]=snpeff.tar.gz
  [plantai-bff]=plantai-bff.tar.gz
  [rice-download]=rice_download.tar.gz
  [rice-rna]=rice_rna-dp.tar.gz
  [beagle54]=beagle54-dp.tar.gz
  [bioinfo]=bioinfo.tar.gz
  [testpy311]=testpy311.tar.gz
  [ani]=ani-dp.tar.gz
  [vcflinshi]=vcflinshi-dp.tar.gz
  [biolabx-assembly]=biolabx-assembly.tar.gz
  [biolabx-bioinfo]=biolabx-bioinfo-missing.tar.gz
  [biolabx-smoke-tools]=biolabx-smoke-tools.tar.gz
  [biolabx-variant-tools]=biolabx-variant-tools.tar.gz
  [pymol-env]=pymol-env.tar.gz
)
ORDER=(minerupy312 at-sc snpeff plantai-bff rice-download rice-rna beagle54 bioinfo \
       testpy311 ani vcflinshi biolabx-assembly biolabx-bioinfo biolabx-smoke-tools \
       biolabx-variant-tools pymol-env)

build_one() {
  local img="$1"
  local tarf="${TARS[$img]}"
  [[ -f "$PACK_DIR/$tarf" ]] || { echo "[FAIL] missing pack artifact: $tarf" >&2; return 2; }
  # 构建上下文: pack-dir 下 stage(硬链接 tar, 同文件系统; 非内核镜像无源码)
  local stage
  stage="$(mktemp -d "$PACK_DIR/.buildenv.XXXXXX")"
  ln "$PACK_DIR/$tarf" "$stage/$tarf"
  echo "[BUILD] plantai-env-$img ($tarf)"
  docker build \
    --build-arg BASE_IMAGE="ubuntu:24.04" \
    --build-arg ENV_TAR="$tarf" \
    -f "$DF_DIR/Dockerfile.plantai-env-$img" \
    -t "plantai-env-$img:$TAG" \
    "$stage"
  rm -rf "$stage"
  echo "[OK] plantai-env-$img"
}

if [[ "$TARGET" == "all" ]]; then
  for img in "${ORDER[@]}"; do
    build_one "$img"
  done
else
  IFS=, read -ra IMGS <<< "$TARGET"
  for img in "${IMGS[@]}"; do
    [[ -n "${TARS[$img]:-}" ]] || { echo "unknown image: $img" >&2; exit 2; }
    build_one "$img"
  done
fi
