#!/usr/bin/env python3
"""Backward-compatible entry point; delegates to apps/cli/run_pep.py."""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from cli.run_pep import main

if __name__ == "__main__":
    raise SystemExit(main())
