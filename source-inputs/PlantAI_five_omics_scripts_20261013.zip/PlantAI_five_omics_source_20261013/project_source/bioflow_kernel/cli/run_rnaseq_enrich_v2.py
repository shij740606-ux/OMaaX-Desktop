#!/usr/bin/env python3
"""Compatibility wrapper for the revised RNA-seq enrichment runner."""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).absolute().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from cli.run_rnaseq_enrich import main


if __name__ == "__main__":
    raise SystemExit(main())
