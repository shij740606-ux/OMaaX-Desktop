# 输入与参数

合法入口：配对FASTQ+数据库；Bracken样本表；丰度+metadata；MAG组装分支。

参数权威为capabilities的parameters字段。必填、类型、choices、默认值和来源由CLI契约审核；不在Skill内复制另一套参数表。

文件先登记获得$asset:ID，只读保存源路径、角色、sha256及事实；变更同一路径内容需重新登记/修订。

分类与MAG是分开的目标；Bracken需独立数据库行。记录profiler、数据库版本、分类层级和abundance_type。完整GTDB未覆盖且不可自行下载。

可选分支缺信息时不启用。源码与环境未验证的入口应标为未覆盖，不自动找网络脚本。

上下游交接：可先登记带完整样本身份的CSV模板，path列写明本计划前序产物，例如@singlecell_upstream:明确的矩阵路径、@spatial_export:exported.h5ad或@metagenome_profile:明确的Bracken文件。必须指定真实发布文件名；模型不能猜测。执行时只解析本任务已验收且SHA256一致的产物，生成本尝试专用CSV并保留原模板。缺少样本身份或未验收产物时停止询问。
