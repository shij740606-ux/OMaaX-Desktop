# 输入与参数

合法入口：FASTQ+samples.yaml；现有CLI支持的count_matrix+samples.yaml下游入口。

参数权威为capabilities的parameters字段。必填、类型、choices、默认值和来源由CLI契约审核；不在Skill内复制另一套参数表。

文件先登记获得$asset:ID，只读保存源路径、角色、sha256及事实；变更同一路径内容需重新登记/修订。

沿用现有CLI，不把任意BAM/FPKM/log数据称为支持的counts入口；组别、独立重复及比较写入samples.yaml，counts入口不重跑上游。

可选分支缺信息时不启用。源码与环境未验证的入口应标为未覆盖，不自动找网络脚本。

配对RNA-seq：samples.yaml需显式subject_id。完整两组配对使用固定CLI的M2模型（~ subject_id + condition）；技术重复、不完整配对、配对多批次及更复杂联合设计须阻止执行并询问，不能退回独立组。


比对与基因计数必须登记样本配置，并逐样本声明library_strandness（或原CLI认可的别名）；non_stranded、forward、reverse的语义由固定CLI规范化。不将缺失值或auto默认为非链特异性。sample_config显式绑定登记配置；不扫描同目录其他样本表重新推断样本。counts下游入口不要求补FASTQ链特异性。
