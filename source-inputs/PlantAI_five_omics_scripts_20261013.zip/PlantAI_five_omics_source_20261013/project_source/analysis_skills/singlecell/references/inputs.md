# 输入与参数

合法入口：10x FASTQ；样本计数表；注释H5AD；pseudobulk counts+metadata；富集集合。

参数权威为capabilities的parameters字段。必填、类型、choices、默认值和来源由CLI契约审核；不在Skill内复制另一套参数表。

文件先登记获得$asset:ID，只读保存源路径、角色、sha256及事实；变更同一路径内容需重新登记/修订。

单核入口明确snRNA及intron；人工注释须使用真实映射；DE要求donor/group/cell_type、至少3独立供体/组和合法配对，批次整合不能修复混杂。

可选分支缺信息时不启用。源码与环境未验证的入口应标为未覆盖，不自动找网络脚本。

上下游交接：可先登记带完整样本身份的CSV模板，path列写明本计划前序产物，例如@singlecell_upstream:明确的矩阵路径、@spatial_export:exported.h5ad或@metagenome_profile:明确的Bracken文件。必须指定真实发布文件名；模型不能猜测。执行时只解析本任务已验收且SHA256一致的产物，生成本尝试专用CSV并保留原模板。缺少样本身份或未验收产物时停止询问。
