# 参数与版本

工具参数的唯一权威是 /api/bioflow/analysis/capabilities 或 analysis_cli.py capabilities 返回的本版契约。当前版本 analysis-contracts/2。

只允许schema中存在的字段，未知参数、任意shell、工具二进制路径、脚本路径、工作目录和环境变量会被拒绝。外部数据必须先登记，再用 $asset:ID 绑定；本任务前序节点产物用 @stage:安全相对路径。默认值标记default，用户修改标记user/revised；设计与来源声明不从默认值猜测。

当前开发预算为每次1CPU、2GiB实际内存、600秒阶段超时；系统盘5,000,000,000字节保留线、结果分区1GiB保留线。上游max_cpus与并行数不能超过预算。调整资源须通过服务配置审核，不是模型传env或命令。

冻结科学CLI的可调参数保持原定义；新控制器增加输入、设计和输出校验。空间至少99次置换，正式推断需审核功效与多重检验。pseudobulk DE使用pb_id/donor/group/cell_type，比较组明确，合法供体和配对条件按细胞类型校验；没有合格类型时阻止执行。

RNA-seq/基因家族仅开放真实CLI解析器中注册的参数；更多中间入口须逐工具验证，不宣称所有格式均支持。
